# Penetration Testing Toolkit

This toolkit includes basic modules for port scanning and brute-force FTP login attacks. It is for **educational** and **authorized** use only.

## Features

- Port Scanner (Common ports)
- FTP Brute-Forcer (with basic wordlist)
- CLI interface

## Requirements

```bash
python main.py
```

## Legal Disclaimer

Use this tool only on systems you own or have permission to test.
