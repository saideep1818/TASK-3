from modules import port_scanner, brute_forcer

def main():
    while True:
        print("\nPenetration Testing Toolkit")
        print("1. Port Scanner")
        print("2. FTP Brute Forcer")
        print("3. Exit")
        choice = input("Enter your choice: ")

        if choice == '1':
            target = input("Enter target IP or domain: ")
            port_scanner.scan_ports(target)
        elif choice == '2':
            target = input("Enter target FTP server: ")
            username = input("Enter username: ")
            passwords = ["admin", "1234", "password", "letmein"]
            brute_forcer.ftp_brute_force(target, username, passwords)
        elif choice == '3':
            break
        else:
            print("Invalid choice")

if __name__ == "__main__":
    main()
